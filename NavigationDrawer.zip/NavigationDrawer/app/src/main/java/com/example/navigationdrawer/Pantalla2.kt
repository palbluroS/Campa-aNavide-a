package com.example.navigationdrawer

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun Pantalla2() {
    LazyColumn() {
        item {
            Text(text = "Pantalla 2")
        }
    }
}